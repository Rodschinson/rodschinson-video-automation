#!/usr/bin/env node
/**
 * =============================================================================
 * RODSCHINSON — Puppeteer Renderer
 * =============================================================================
 * Remplace render_manim.py — même interface, même JSON script
 *
 * USAGE :
 *   node renderer.js --script ../output/scripts/script_rod_xxx.json
 *   node renderer.js --script ... --template news_reel
 *   node renderer.js --script ... --scene 1
 *   node renderer.js --script ... --quality h    (h=1080p m=720p l=480p)
 *
 * RÉSULTAT :
 *   output/scenes/scene_01_hook.mp4
 *   output/scenes/scene_02_introduction.mp4
 *   ...
 * =============================================================================
 */

const puppeteer = require('puppeteer');
const { execSync, spawnSync } = require('child_process');
const fs   = require('fs');
const path = require('path');

// ── CONFIG ───────────────────────────────────────────────────────────────────

const ROOT       = path.resolve(__dirname, '..');
const SCENES_OUT = path.join(ROOT, 'output', 'scenes');
const TMPL_DIR   = path.join(__dirname, 'templates');

const QUALITY = {
  h: { width: 1920, height: 1080, fps: 30 },
  m: { width: 1280, height: 720,  fps: 30 },
  l: { width: 854,  height: 480,  fps: 24 },
};

const TEMPLATES = {
  rodschinson_premium: 'rodschinson_premium.html',
  news_reel:           'news_reel.html',
  tech_data:           'tech_data.html',
  corporate_minimal:   'corporate_minimal.html',
};

// ── ARGS ─────────────────────────────────────────────────────────────────────

function parseArgs() {
  const args = process.argv.slice(2);
  const get = (flag) => {
    const i = args.indexOf(flag);
    return i !== -1 && args[i+1] ? args[i+1] : null;
  };
  return {
    script:   get('--script'),
    template: get('--template') || 'rodschinson_premium',
    scene:    get('--scene') ? parseInt(get('--scene')) : null,
    quality:  get('--quality') || 'h',
    fps:      get('--fps') ? parseInt(get('--fps')) : null,
  };
}

// ── RENDER ONE SCENE ─────────────────────────────────────────────────────────

async function renderScene(browser, sceneData, opts) {
  const { width, height, fps, templatePath, outputPath, tmpDir } = opts;

  const sid  = sceneData.id;
  const nom  = sceneData.nom || `scene_${sid}`;
  const dur  = sceneData.duree_sec || 5;
  const type = sceneData.type_visuel;
  const frames = dur * fps;

  process.stdout.write(`  [${String(sid).padStart(2,'0')}] ${nom.padEnd(28)} [${type}]  ${dur}s  ... `);

  // Open page
  const page = await browser.newPage();
  await page.setViewport({ width, height, deviceScaleFactor: 1 });

  const tmplUrl = `file://${templatePath}`;
  await page.goto(tmplUrl, { waitUntil: 'networkidle0' });

  // Load scene data into template
  const loaded = await page.evaluate((sd) => {
    return window.loadScene(sd);
  }, sceneData);

  if (!loaded) {
    await page.close();
    console.log('❌ (type non supporté)');
    return null;
  }

  // Trigger animations
  await page.evaluate(() => window.animateScene());

  // Wait for entry animations
  await new Promise(r => setTimeout(r, 800));

  // Capture frames
  const frameDir = path.join(tmpDir, `scene_${sid}`);
  fs.mkdirSync(frameDir, { recursive: true });

  for (let f = 0; f < frames; f++) {
    const framePath = path.join(frameDir, `frame_${String(f).padStart(5,'0')}.png`);
    await page.screenshot({ path: framePath, type: 'png' });

    // Update animation state at specific frames
    const progress = f / frames;
    if (f === Math.floor(frames * 0.15)) {
      // Trigger staggered items mid-way
      await page.evaluate(() => {
        const items = document.querySelectorAll('.ps-step, .tb-item, .an-point, .dp-stat');
        items.forEach((el, i) => {
          el.style.opacity = '1';
          el.style.transform = 'none';
        });
      });
    }
  }

  await page.close();

  // Assemble frames → MP4 with FFmpeg
  const framePattern = path.join(frameDir, 'frame_%05d.png');
  const result = spawnSync('ffmpeg', [
    '-y',
    '-framerate', String(fps),
    '-i', framePattern,
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-crf', '18',
    '-preset', 'fast',
    outputPath,
  ], { stdio: 'pipe' });

  // Cleanup frames
  fs.rmSync(frameDir, { recursive: true, force: true });

  if (result.status !== 0) {
    console.log('❌');
    console.error(result.stderr.toString().slice(-300));
    return null;
  }

  const size = Math.round(fs.statSync(outputPath).size / 1024);
  console.log(`✅ ${path.basename(outputPath)}  (${size} KB)`);
  return outputPath;
}

// ── MAIN ─────────────────────────────────────────────────────────────────────

async function main() {
  const args = parseArgs();

  if (!args.script) {
    console.error('Usage: node renderer.js --script path/to/script.json');
    process.exit(1);
  }

  const script   = JSON.parse(fs.readFileSync(args.script, 'utf8'));
  const meta     = script.meta || {};
  const scenes   = script.scenes || [];
  const qual     = QUALITY[args.quality] || QUALITY.h;
  const fps      = args.fps || qual.fps;

  // Determine template
  const templateName = args.template || meta.template || 'rodschinson_premium';
  const tmplFile     = TEMPLATES[templateName] || TEMPLATES.rodschinson_premium;
  const templatePath = path.join(TMPL_DIR, tmplFile);

  if (!fs.existsSync(templatePath)) {
    console.error(`Template introuvable: ${templatePath}`);
    process.exit(1);
  }

  console.log('\n' + '═'.repeat(60));
  console.log(`  🎬  ${meta.titre || ''}`);
  console.log(`  Brand : ${meta.brand || ''}  |  ${meta.format || ''} ${meta.ratio || ''}`);
  console.log(`  ${scenes.length} scènes  |  qualité ${args.quality}  |  template: ${templateName}`);
  console.log('═'.repeat(60) + '\n');

  fs.mkdirSync(SCENES_OUT, { recursive: true });

  const tmpDir = fs.mkdtempSync('/tmp/rod_puppeteer_');

  const browser = await puppeteer.launch({
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      `--window-size=${qual.width},${qual.height}`,
    ],
  });

  const rendered = [];
  const errors   = [];

  try {
    for (const scene of scenes) {
      if (args.scene && scene.id !== args.scene) continue;

      const outName = `scene_${String(scene.id).padStart(2,'0')}_${scene.nom || 'scene'}.mp4`;
      const outPath = path.join(SCENES_OUT, outName);

      const result = await renderScene(browser, scene, {
        width:        qual.width,
        height:       qual.height,
        fps,
        templatePath,
        outputPath:   outPath,
        tmpDir,
      });

      if (result) rendered.push(result);
      else errors.push(scene.id);
    }
  } finally {
    await browser.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }

  console.log('\n' + '─'.repeat(60));
  console.log(`  ✅ ${rendered.length} scènes  |  ❌ ${errors.length} erreur(s)`);
  console.log(`  📁 ${SCENES_OUT}`);

  if (rendered.length > 0) {
    console.log(`\n  Étape suivante :`);
    console.log(`  python scripts/generate_audio.py --script ${args.script}`);
  }

  process.exit(errors.length > 0 ? 1 : 0);
}

main().catch(err => {
  console.error('Fatal:', err);
  process.exit(1);
});
